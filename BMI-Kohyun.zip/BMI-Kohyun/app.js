const express = require("express");
const bodyParser = require('body-parser');

const app = express();

app.use(express.static('public'));
app.use(bodyParser.urlencoded({extended: true}));

//use ejs
app.set('view engine', 'ejs');

app.get('/', function(req, res){
    res.render('bmi', {
        age: '',  weight: '',  height: '',  BMIresult: ''});
});


app.post('/', function(req, res){
    var age = Number(req.body.age);
    var weight =Number(req.body.weight); 
    var height = Number(req.body.height); 
    var bmi =parseFloat(weight / (height * height)).toFixed(2); 


    var str = 'Your BMI Result is: ' + bmi; 
    res.render('bmi', {
        age: age,
        weight: weight,
        height: height, 
        BMIresult: str});
});

//listens on port 3000
app.listen(3000, function(){
    console.log("server started on port 3000");
});